public class VideoGame {

    public String marca;
    public String modelo;
    public String cor;
    public int numeroMemoria;
    public boolean ligado = false;



    public VideoGame() {
        marca = null;
        modelo = null;
        cor = null;
    }

    public VideoGame(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
        this.cor = null;
    }

    public VideoGame(String marca, String modelo, String cor) {

        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;

    }

    public void ligar() {
        ligado = true;
        System.out.println(modelo + ": " + "Bem vindo!");
    }

    public void desligar() {
        ligado = false;
        System.out.println("Até Logo!");
    }
    public void escolhaSeuJogo(){
        if(ligado){
            System.out.println("Escolha seu jogo: ");
        }

    }

    public void acesarJogo() {
        if(ligado) {
            System.out.println("Entrando no jogo! Aproveite :D ");
        }
    }

    public void abrirBandeija() {
        if(ligado) {
            System.out.println("Abrindo a bandeija, insira o CD");
        }
    }

    public void fecharBandeija() {
        if(ligado) {
            System.out.println("Fechando a bandeija. Cuidado com o dedo!");
        }
    }
}
