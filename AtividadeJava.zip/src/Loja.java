import java.util.Scanner;

public class Loja {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        VideoGame VideoGame1 = new VideoGame();


//        VideoGame1.marca = "PlayStation";
//        VideoGame1.modelo = "Ps4";
//        VideoGame1.cor = "Preto";
//        VideoGame1.numeroMemoria = 1000;
        VideoGame1.ligar();
        VideoGame1.escolhaSeuJogo();
        VideoGame1.acesarJogo();
        VideoGame1.desligar();

        System.out.println(VideoGame1.marca + " " + VideoGame1.modelo + " " + VideoGame1.cor + " ");

        VideoGame VideoGame2 = new VideoGame("Xbox", "SeriesX");
        System.out.println(VideoGame2);
//        VideoGame2.marca = "Xbox";
//        VideoGame2.modelo = "OneS";

        VideoGame2.ligar();
        VideoGame2.abrirBandeija();
        VideoGame2.fecharBandeija();
        VideoGame2.acesarJogo();
        VideoGame2.desligar();
        System.out.println(VideoGame2.marca + " " + VideoGame2.modelo);


        VideoGame VideoGame3 = new VideoGame("Nintendo", "3ds");
        System.out.println(VideoGame3);
        VideoGame3.ligar();
        VideoGame3.escolhaSeuJogo();
        VideoGame3.acesarJogo();
        VideoGame3.desligar();

    }
}

